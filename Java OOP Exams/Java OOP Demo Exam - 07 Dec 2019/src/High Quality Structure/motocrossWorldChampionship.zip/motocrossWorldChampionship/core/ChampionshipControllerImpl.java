package motocrossWorldChampionship.core;

import motocrossWorldChampionship.core.interfaces.ChampionshipController;

public class ChampionshipControllerImpl implements ChampionshipController {

    @Override
    public String createRider(String riderName) {
        return null;
    }

    @Override
    public String createMotorcycle(String type, String model, int horsePower) {
        return null;
    }

    @Override
    public String addMotorcycleToRider(String riderName, String motorcycleModel) {
        return null;
    }

    @Override
    public String addRiderToRace(String raceName, String riderName) {
        return null;
    }

    @Override
    public String startRace(String raceName) {
        return null;
    }

    @Override
    public String createRace(String name, int laps) {
        return null;
    }
}
