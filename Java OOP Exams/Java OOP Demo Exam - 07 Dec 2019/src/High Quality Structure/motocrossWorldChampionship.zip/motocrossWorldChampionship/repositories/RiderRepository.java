package motocrossWorldChampionship.repositories;

import motocrossWorldChampionship.entities.interfaces.Rider;
import motocrossWorldChampionship.repositories.interfaces.Repository;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public class RiderRepository implements Repository<Rider> {

    private Map<String,Rider> riders;

    public RiderRepository() {
        this.riders = new LinkedHashMap<>();
    }

    @Override
    public Rider getByName(String name) {
        return this.riders.get(name);
    }

    @Override
    public Collection<Rider> getAll() {
        return Collections.unmodifiableCollection(this.riders.values());
    }

    @Override
    public void add(Rider model) {
        this.riders.put(model.getName(),model);
    }

    @Override
    public boolean remove(Rider model) {
        return this.riders.remove(model.getName())!=null;
    }
}
