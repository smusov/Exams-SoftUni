package motocrossWorldChampionship.repositories;

import motocrossWorldChampionship.entities.interfaces.Race;
import motocrossWorldChampionship.repositories.interfaces.Repository;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public class RaceRepository implements Repository<Race> {

    private Map<String,Race> racers;

    public RaceRepository() {
        this.racers = new LinkedHashMap<>();
    }

    @Override
    public Race getByName(String name) {
        return this.racers.get(name);
    }

    @Override
    public Collection<Race> getAll() {
        return Collections.unmodifiableCollection(this.racers.values());
    }

    @Override
    public void add(Race model) {
        this.racers.put(model.getName(),model);
    }

    @Override
    public boolean remove(Race model) {
        return this.racers.remove(model.getName())!=null;
    }
}
