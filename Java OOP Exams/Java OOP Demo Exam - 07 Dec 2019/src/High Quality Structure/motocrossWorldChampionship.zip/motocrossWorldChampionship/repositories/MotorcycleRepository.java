package motocrossWorldChampionship.repositories;

import motocrossWorldChampionship.entities.interfaces.Motorcycle;
import motocrossWorldChampionship.repositories.interfaces.Repository;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public class MotorcycleRepository implements Repository<Motorcycle> {

    private Map<String, Motorcycle> motorcycles;

    public MotorcycleRepository() {
        this.motorcycles = new LinkedHashMap<>();
    }

    @Override
    public Motorcycle getByName(String name) {
        return this.motorcycles.get(name);
    }

    @Override
    public Collection<Motorcycle> getAll() {
        return Collections.unmodifiableCollection(this.motorcycles.values());
    }

    @Override
    public void add(Motorcycle model) {
        this.motorcycles.put(model.getModel(),model);
    }

    @Override
    public boolean remove(Motorcycle model) {
        return this.motorcycles.remove(model.getModel())!=null;
    }
}
