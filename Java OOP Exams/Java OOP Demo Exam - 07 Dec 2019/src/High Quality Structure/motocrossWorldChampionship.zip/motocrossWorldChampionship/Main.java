package motocrossWorldChampionship;

import motocrossWorldChampionship.entities.SpeedMotorcycle;

public class Main {
    public static void main(String[] args) {



    }
}
