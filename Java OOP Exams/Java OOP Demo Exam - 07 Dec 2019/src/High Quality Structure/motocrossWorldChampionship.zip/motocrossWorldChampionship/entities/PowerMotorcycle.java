package motocrossWorldChampionship.entities;

public class PowerMotorcycle extends MotorcycleImpl {
    public PowerMotorcycle(String model, int horsePower) {
        super(model, setHorsePower(horsePower), 450);
    }

    private static int setHorsePower(int horsePower) {
        if (horsePower<70||horsePower>100){
            throw new IllegalArgumentException(String.format("Invalid horse power: %d.",horsePower));
        }
        return horsePower;
    }
}
