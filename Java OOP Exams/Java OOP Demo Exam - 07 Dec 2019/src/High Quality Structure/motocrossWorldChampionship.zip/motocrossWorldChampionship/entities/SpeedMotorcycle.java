package motocrossWorldChampionship.entities;

public class SpeedMotorcycle extends MotorcycleImpl {
    public SpeedMotorcycle(String model, int horsePower) {
        super(model, setHorsePower(horsePower), 125);
    }

    private static int setHorsePower(int horsePower) {
        if (horsePower<50||horsePower>69){
            throw new IllegalArgumentException(String.format("Invalid horse power: %d.",horsePower));
        }
        return horsePower;
    }
}
