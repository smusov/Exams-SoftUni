package unitTesting;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;

public class RaceEntryTest {

    private RaceEntry raceEntry;
    private UnitMotorcycle motorcycle;
    private UnitRider rider;

    @Before
    public void initialiseRaceEntry(){
        this.raceEntry = new RaceEntry();
        this.motorcycle = new UnitMotorcycle("FirstTest",42,69);
        this.rider = new UnitRider("TestRider",this.motorcycle);
    }

    @Test(expected = NullPointerException.class)
    public void addRiderShouldThrowExceptionIfRiderIsNull(){
        this.raceEntry.addRider(null);
    }

    @Test
    public void addRiderShouldThrowExceptionIfRiderIsNullWithCorrectMessage(){

        final String expected = "Rider cannot be null.";
        String actual = "";

        try {
            this.raceEntry.addRider(null);
        }catch (NullPointerException ex){
            actual = ex.getMessage();
        }

        Assert.assertEquals(expected,actual);
    }

    @Test
    public void addRiderShouldThrowExceptionIfRiderAreExistWithCorrectMessage(){
        final String expected = "Rider TestRider is already added";

        String actual = "";

        try {

            this.raceEntry.addRider(this.rider);
            this.raceEntry.addRider(this.rider);

        }catch (IllegalArgumentException ex){
            actual = ex.getMessage();
        }

        Assert.assertEquals(expected,actual);

    }


    @Test(expected = IllegalArgumentException.class)
    public void addRiderShouldThrowExceptionIfRiderAreExist(){

        this.raceEntry.addRider(this.rider);
        this.raceEntry.addRider(this.rider);
    }

    @Test
    public void addRiderShouldReturnCorrectMessageIfRiderAddedSuccessful(){

        final String expected = "Rider TestRider added in race.";
        String actual = this.raceEntry.addRider(this.rider);

        Assert.assertEquals(expected,actual);
    }

    @Test(expected = IllegalArgumentException.class)
    public void calculateAverageHorsePowerShouldThrowExceptionIfRidersLessExpectedCount(){

        this.raceEntry.addRider(this.rider);
        this.raceEntry.calculateAverageHorsePower();
    }

    @Test
    public void calculateAverageHorsePowerShouldThrowExceptionIfRidersLessExpectedCountWithCorrectMessage(){
        this.raceEntry.addRider(this.rider);

        final String expected = "The race cannot start with less than 2 participants.";

        String actual = "";

        try {
            this.raceEntry.calculateAverageHorsePower();
        }catch (IllegalArgumentException ex){
            actual = ex.getMessage();
        }

        Assert.assertEquals(expected,actual);
    }

    @Test
    public void calculateAverageHorsePowerShouldReturnCorrectValue(){
        this.raceEntry.addRider(this.rider);
        this.raceEntry.addRider(new UnitRider("SecondTest",this.motorcycle));
        this.raceEntry.addRider(new UnitRider("ThirdTest",this.motorcycle));

        final double expected = 42.0;
        double actual = this.raceEntry.calculateAverageHorsePower();

        Assert.assertEquals(expected,actual,0);
    }

    @Test
    public void getRidersShouldBeReturnCollectionWithCorrectValues(){


        UnitRider secondTest = new UnitRider("SecondTest", this.motorcycle);
        UnitRider thirdTest = new UnitRider("ThirdTest", this.motorcycle);

        Collection<UnitRider> expected = new ArrayList<>();

        expected.add(this.rider);
        expected.add(secondTest);
        expected.add(thirdTest);

        this.raceEntry.addRider(this.rider);
        this.raceEntry.addRider(secondTest);
        this.raceEntry.addRider(thirdTest);

        Collection<UnitRider> actual = new ArrayList<>(this.raceEntry.getRiders());

        Assert.assertEquals(expected,actual);
        Assert.assertEquals(expected.size(),actual.size());
    }

    @Test(expected = UnsupportedOperationException.class)
    public void getRidersShouldBeReturnUnmodifiableCollection() {
        this.raceEntry.getRiders().clear();
    }
}
