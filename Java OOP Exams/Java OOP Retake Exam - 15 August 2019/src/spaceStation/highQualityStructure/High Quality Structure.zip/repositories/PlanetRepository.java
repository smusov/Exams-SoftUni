package spaceStation.repositories;

import spaceStation.models.planets.Planet;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class PlanetRepository implements Repository {

    private List<Planet> planets;

    @Override
    public Collection getModels() {
        return Collections.unmodifiableList(this.planets);
    }

    @Override
    public void add(Object model) {
        this.planets.add((Planet)model);
    }

    @Override
    public boolean remove(Object model) {
        return this.planets.remove((Planet)model);
    }

    @Override
    public Object findByName(String name) {
        return this.planets.stream().filter(e->e.getName().equals(name)).findFirst().orElse(null);
    }
}
