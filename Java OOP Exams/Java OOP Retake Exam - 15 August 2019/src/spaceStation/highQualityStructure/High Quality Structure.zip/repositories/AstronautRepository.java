package spaceStation.repositories;

import spaceStation.models.astronauts.Astronaut;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class AstronautRepository implements Repository {

    private List<Astronaut> astronauts;

    public AstronautRepository() {
        this.astronauts = new ArrayList<>();
    }

    @Override
    public Collection getModels() {
        return Collections.unmodifiableList(this.astronauts);
    }

    @Override
    public void add(Object model) {
        this.astronauts.add((Astronaut)model);
    }

    @Override
    public boolean remove(Object model) {
        return this.astronauts.remove((Astronaut) model);
    }

    @Override
    public Object findByName(String name) {
        return this.astronauts.stream().filter(e->e.getName().equals(name)).findFirst().orElse(null);
    }
}
