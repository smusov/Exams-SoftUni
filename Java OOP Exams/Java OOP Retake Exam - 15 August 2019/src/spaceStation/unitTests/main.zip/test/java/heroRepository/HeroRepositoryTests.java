package heroRepository;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.*;

public class HeroRepositoryTests {

    private HeroRepository heroRepository;

    @Before
    public void initialiseHeroRepository(){
        this.heroRepository = new HeroRepository();
    }


    @Test
    public void getCountShouldBeZero(){
        int count = this.heroRepository.getCount();
        Assert.assertEquals(0,count);
    }

    @Test(expected = NullPointerException.class)
    public void createHeroShouldBeThrowNullPointerException(){
        this.heroRepository.create(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void createHeroShouldBeThrowIllegalArgumentIfHeroContains(){
        this.heroRepository.create(new Hero("Test",1));
        this.heroRepository.create(new Hero("Test",1));
    }

    @Test
    public void createHeroShouldBeAddedSuccessfulHero(){
        this.heroRepository.create(new Hero("Test",69));
        Assert.assertEquals(1,this.heroRepository.getCount());
    }
    @Test(expected = NullPointerException.class)
    public void removeShouldBeThrowNewNullPointerIfInvokeWithNullValue(){
        this.heroRepository.remove(null);
    }
    @Test(expected = NullPointerException.class)
    public void removeShouldBeThrowNewNullPointerIfInvokeWithEmptyStringOrOnlySpaces(){
        this.heroRepository.remove("               ");
    }
    @Test
    public void getHeroWithHighestLevelShouldBeReturnCorrectValue(){

        Hero hero = new Hero("test2",69);

        this.heroRepository.create(new Hero("asd",42));
        this.heroRepository.create(new Hero("test",32));
        this.heroRepository.create(hero);

        Assert.assertEquals(hero,this.heroRepository.getHeroWithHighestLevel());
    }

    @Test
    public void getHeroWithHighestLevelShouldBeReturnNullIfNotAddedHeroes(){
        Assert.assertNull(this.heroRepository.getHeroWithHighestLevel());
    }

    @Test
    public void getHeroShouldBeReturnCorrectHero(){

        Hero hero = new Hero("test3", 69);

        this.heroRepository.create(new Hero("test",1));
        this.heroRepository.create(new Hero("test2",68));
        this.heroRepository.create(hero);

        Assert.assertEquals(hero,this.heroRepository.getHero("test3"));

    }

    @Test
    public void getHeroShouldBeReturnIfNotAddedHeroesOrNotContainsHeroWithGivenName(){
        Assert.assertNull(this.heroRepository.getHero("asd"));
    }

    @Test
    public void getHeroesShouldBeReturnCollectWithGivenHeroes(){
        Collection<Hero> heroCollections = new ArrayList<>();

        Hero hero = new Hero("test1",42);
        Hero hero2 = new Hero("test2",69);
        Hero hero3 = new Hero("test3",7);

        heroCollections.add(hero);
        heroCollections.add(hero2);
        heroCollections.add(hero3);

        this.heroRepository.create(hero);
        this.heroRepository.create(hero2);
        this.heroRepository.create(hero3);


        List<Hero> collection = new ArrayList<>(this.heroRepository.getHeroes());

        Assert.assertEquals(heroCollections,collection);
    }
}

