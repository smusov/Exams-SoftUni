package callofduty.interfaces;

import callofduty.interfaces.agents.Bountyable;
import callofduty.interfaces.agents.Identifiable;
import callofduty.interfaces.agents.Rateable;

public interface Mission extends Identifiable, Rateable, Bountyable {
}
