package callofduty.interfaces.agents;

public interface Identifiable {
    String getId();
}
