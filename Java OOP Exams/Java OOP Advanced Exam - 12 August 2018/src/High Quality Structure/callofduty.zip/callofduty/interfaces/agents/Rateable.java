package callofduty.interfaces.agents;

public interface Rateable {
    Double getRating();
}
