package callofduty.interfaces.agents;

public interface Nameable {
    String getName();
}
