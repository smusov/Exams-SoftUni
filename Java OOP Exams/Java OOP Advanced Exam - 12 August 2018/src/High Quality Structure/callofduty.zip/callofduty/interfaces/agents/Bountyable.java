package callofduty.interfaces.agents;

public interface Bountyable {
    Double getBounty();
}
