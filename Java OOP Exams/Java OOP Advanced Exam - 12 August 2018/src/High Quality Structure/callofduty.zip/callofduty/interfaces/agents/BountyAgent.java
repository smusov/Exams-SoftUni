package callofduty.interfaces.agents;

public interface BountyAgent extends Agent, Bountyable {
}
