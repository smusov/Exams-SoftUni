package callofduty.interfaces.agents;

import callofduty.interfaces.Mission;

public interface Agent extends Identifiable, Nameable, Rateable {
    void acceptMission(Mission mission);

    void completeMissions();
}
