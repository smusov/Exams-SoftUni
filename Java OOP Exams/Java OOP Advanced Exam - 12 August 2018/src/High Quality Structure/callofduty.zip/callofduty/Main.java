package callofduty;

import callofduty.core.MissionControlImpl;
import callofduty.interfaces.Mission;
import callofduty.interfaces.MissionControl;
import callofduty.models.missions.EscortMission;

public class Main {
    public static void main(String[] args)  {
      	//TODO: Implement me ...

        MissionControl missionControl = new MissionControlImpl();
        missionControl.generateMission("4",5.0,58.00);
    }
}




