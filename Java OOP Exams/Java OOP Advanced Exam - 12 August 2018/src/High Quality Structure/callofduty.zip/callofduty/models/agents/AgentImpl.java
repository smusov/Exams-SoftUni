package callofduty.models.agents;

import callofduty.interfaces.agents.Agent;
import callofduty.interfaces.Mission;

import java.util.ArrayList;
import java.util.List;

public abstract class AgentImpl implements Agent {

    private String id;
    private String name;
    private Double rating;
    private List<Mission> missions;

    protected AgentImpl(String id, String name, Double rating) {
        this.id = id;
        this.name = name;
        this.rating = rating;
        this.missions = new ArrayList<>();
    }

    @Override
    public void acceptMission(Mission mission) {
        this.missions.add(mission);
    }

    @Override
    public void completeMissions() {

    }

    @Override
    public String getId() {
        return this.id;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public Double getRating() {
        return this.rating;
    }
}
