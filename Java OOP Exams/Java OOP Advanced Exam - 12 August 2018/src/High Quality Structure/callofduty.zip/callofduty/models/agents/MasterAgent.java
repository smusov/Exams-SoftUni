package callofduty.models.agents;

import callofduty.interfaces.agents.BountyAgent;

public class MasterAgent extends AgentImpl implements BountyAgent {

    private static final Double DEFAULT_BOUNTY = 0.0;

    private Double bounty;

    protected MasterAgent(String id, String name, Double rating) {
        super(id, name, rating);
        this.bounty = DEFAULT_BOUNTY;
    }

    @Override
    public Double getBounty() {
        return this.bounty;
    }
}
