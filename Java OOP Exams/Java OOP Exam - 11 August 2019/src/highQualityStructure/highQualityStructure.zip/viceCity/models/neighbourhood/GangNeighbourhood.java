package viceCity.models.neighbourhood;

import viceCity.models.guns.Gun;
import viceCity.models.players.Player;

import java.util.Collection;

public class GangNeighbourhood implements Neighbourhood {

    @Override
    public void action(Player mainPlayer, Collection<Player> civilPlayers) {

        if (mainPlayerShooting(mainPlayer,civilPlayers)) {

        }else {
            civilPlayersShooting(mainPlayer,civilPlayers);
        }
        
    }

    private void civilPlayersShooting(Player mainPlayer, Collection<Player> civilPlayers) {

    }

    private boolean mainPlayerShooting(Player mainPlayer, Collection<Player> civilPlayers) {

        boolean playerIsNotMoreGun = false;

        for (Gun model : mainPlayer.getGunRepository().getModels()) {
            if (model.canFire()) {
                for (Player civilPlayer : civilPlayers) {
                    civilPlayer.takeLifePoints(model.fire());
                    if (!civilPlayer.isAlive()) {
                        continue;
                    }
                    if (!model.canFire()) {
                        break;
                    }
                }
            }else {
                playerIsNotMoreGun = true;
            }
        }
        return playerIsNotMoreGun;
    }
}
