package parkingSystem;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class SoftParkTest {

    private SoftPark softPark;
    private Car testCar;

    @Before
    public void initialiseObject(){
        this.softPark = new SoftPark();
        this.testCar = new Car("Test","Test");
    }

    @Test
    public void testStartCapacityOfSpot(){
        final int expected = 12;
        int actual = this.softPark.getParking().size();
        Assert.assertEquals(expected,actual);
    }

    @Test(expected = UnsupportedOperationException.class)
    public void getParkingShouldReturnUnmodifiableMap(){
        this.softPark.getParking().clear();
    }

    @Test(expected = IllegalArgumentException.class)
    public void parkCarShouldThrowExceptionIfParkingSpotNotExist(){
        this.softPark.parkCar("Test",testCar);
    }

    @Test
    public void parkCarShouldThrowExceptionIfParkingSpotNotExistWithCorrectMessage(){

        final String expected = "Parking spot doesn't exists!";
        String actual = "";

        try {
            this.softPark.parkCar("Test",testCar);
        }catch (IllegalArgumentException ex){
            actual = ex.getMessage();
        }

        Assert.assertEquals(expected,actual);
    }

    @Test(expected = IllegalArgumentException.class)
    public void parkCarShouldThrowExceptionIfParkingSpotIsTaken(){
        this.softPark.parkCar("A",testCar);
        this.softPark.parkCar("A",testCar);
    }

    @Test
    public void parkCarShouldThrowExceptionIfParkingSpotIsTakenWithCorrectMessage(){

        final String expected = "Parking spot is already taken!";
        String actual = "";

       try {
           this.softPark.parkCar("A1",testCar);
           this.softPark.parkCar("A1",testCar);
       }catch (IllegalArgumentException ex){
           actual = ex.getMessage();
       }

       Assert.assertEquals(expected,actual);
    }

    @Test
    public void parkCarShouldThrowExceptionIfCarAlreadyParked(){

        final String expected = "Car is already parked!";
        String actual = "";

        try {
            this.softPark.parkCar("A1", testCar);
            this.softPark.parkCar("B1", testCar);
        }catch (IllegalStateException ex){
            actual = ex.getMessage();
        }
        Assert.assertEquals(expected,actual);
    }

    @Test
    public void parkCarShouldReturnCorrectMessageIfCarParkSuccessful(){
        final String expected = "Car:Test parked successfully!";
        String actual = this.softPark.parkCar("A1", testCar);

        Assert.assertEquals(expected,actual);
    }

    @Test
    public void getParkingShouldReturnMapWithCorrectValues (){
        this.softPark.parkCar("A1",this.testCar);
        boolean containsTestCar = this.softPark.getParking().get("A1")!=null;
        Assert.assertTrue(containsTestCar);

    }

    @Test(expected = IllegalArgumentException.class)
    public void removeCarShouldThrowExceptionIfParkingSpotNotExist(){
        this.softPark.removeCar("Test",testCar);
    }

    @Test(expected = IllegalArgumentException.class)
    public void removeCarShouldThrowExceptionIfCarForThatSpotDoesntExists(){
        this.softPark.parkCar("A1",testCar);
        this.softPark.removeCar("A1",new Car("SecondTest","SecondTest"));
    }

    @Test
    public void removeCarShouldReturnCorrectMessageIfCarRemovedSuccessful(){
        final String expected = "Remove car:Test successfully!";

        this.softPark.parkCar("A1",testCar);
        String actual = this.softPark.removeCar("A1", testCar);

        Assert.assertEquals(expected,actual);
    }
}