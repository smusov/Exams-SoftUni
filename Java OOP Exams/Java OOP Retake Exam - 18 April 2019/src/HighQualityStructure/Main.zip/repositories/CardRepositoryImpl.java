package repositories;

import models.cards.interfaces.Card;
import repositories.interfaces.CardRepository;

import java.util.ArrayList;
import java.util.List;

public class CardRepositoryImpl implements CardRepository {

    private List<Card> cards;

    public CardRepositoryImpl (){
        this.cards = new ArrayList<>();
    }

    @Override
    public int getCount() {
        return cards.size();
    }

    @Override
    public List<Card> getCards() {
        return this.cards;
    }

    @Override
    public void add(Card card) {
        isNotNullCard(card);
        if (this.cards.contains(card)){
            throw new IllegalArgumentException(String.format("Card %s already exists!",card.getName()));
        }
        this.cards.add(card);
    }

    @Override
    public boolean remove(Card card) {
        isNotNullCard(card);
        return this.cards.remove(card);
    }

    @Override
    public Card find(String name) {
        Card card = null;

        for (Card c : this.cards) {
            if (c.getName().equals(name)){
                card = c;
                break;
            }
        }
        return card;
    }

    private void isNotNullCard(Card card) {
        if (card==null){
            throw new IllegalArgumentException("Card cannot be null!");
        }
    }
}
