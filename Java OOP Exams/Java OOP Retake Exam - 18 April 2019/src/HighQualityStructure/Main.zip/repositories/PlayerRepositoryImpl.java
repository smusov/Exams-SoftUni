package repositories;

import models.players.interfaces.Player;
import repositories.interfaces.PlayerRepository;

import java.util.ArrayList;
import java.util.List;

public class PlayerRepositoryImpl implements PlayerRepository {

    private List<Player> players;

    public PlayerRepositoryImpl() {
        this.players = new ArrayList<>();
    }

    @Override
    public int getCount() {
        return this.players.size();
    }

    @Override
    public List<Player> getPlayers() {
        return this.players;
    }

    @Override
    public void add(Player player) {

        isNotNullPlayer(player);

        if (this.players.contains(player)){
            throw new IllegalArgumentException(String.format("Player %s already exists!",player.getUsername()));
        }
        this.players.add(player);
    }

    @Override
    public boolean remove(Player player) {

        isNotNullPlayer(player);

        return this.players.remove(player);
    }

    @Override
    public Player find(String name) {
        Player player = null;

        for (Player p : this.players) {
            if (p.getUsername().equals(name)){
                player = p;
                break;
            }
        }

        return player;
    }

    private void isNotNullPlayer(Player player) {
        if (player==null){
            throw new IllegalArgumentException("Player cannot be null");
        }
    }
}
